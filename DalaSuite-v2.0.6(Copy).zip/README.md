# Dala Suite — Personal Adobe After Effects Extension

**Platform:** Windows (Windows 10 / 11, 64-bit)  
**After Effects Compatibility:** After Effects 2020 (v17.0) and newer — tested on After Effects 2025 (25.6) and 2026 (26.0); see *After Effects Compatibility* below  
**Architecture:** Adobe CEP Extension (HTML5 / CSS3 / ES6 Frontend + ExtendScript JSX Host Engine)  
**Theme:** Dark Marine Blue Pro Palette (`#070c14`, `#0c1422`, `#121e33`, `#2979ff`)  
**Package:** `DalaSuite-v2.0.6.zxp`  
**License:** Personal Offline Tool (100% Free & Local: No login, no subscriptions, no cloud APIs, no telemetry, no analytics)

---

## Overview

**Dala Suite** is a high-performance, personal Adobe After Effects extension designed for rapid editing workflows, automated layer splitting, speed ramps, dynamic centering, and keyframe stretching. It is built strictly using Adobe's CEP (Common Extensibility Platform) architecture with a dark marine blue interface, fluidly responsive docking, and single-click execution.

---

## What's New in 2.0.6

- **Auto Captions - Woodl timing follows the timing reference.** Each caption layer now starts with its reveal, the preset's lead (0.47 s) before the line is spoken, so the text is seen revealing before the voice instead of popping in half-revealed. The reveal (fade in) is full when the line has been spoken; the sweep-out (fade out) starts where the preset starts it within the reveal (77 % of the way through it) and is gone just before the next line's speech start; tracking runs from the layer start to just past its end. Layers overlap like the reference: one line sweeps out while the next one reveals. A long pause still holds the whole line (its sweep-out waits until 2.5 s before the end). Woodl Style itself is unchanged: the same preset as before (`dala-default.json`, made from `txt-preset-1.aep`).
- **Auto Captions - edit the caption lines freely.** After Test audio the box takes any text: change words, add lines, split or join lines, write long lines. Generate makes one caption per line (no more "N lines are needed" error, no word limit for your own lines) and times every line from the words it shares with the speech: a split line keeps each half where it is spoken, an added line goes after the words before it.
- **Auto Captions - edits update the built layers.** After Generate, editing the box changes the caption layers in the comp a moment after you stop typing: a changed line is rebuilt in its place (same stacking order), added / removed / split / joined lines rebuild the captions of that build. Works for Woodl Style and the Text Preset families. Clear created layers, or Test audio on other audio, ends the link.
- **Auto Captions - Auto or Manual layer updates.** Under the caption lines, **Layers: Auto | Manual**. Auto applies edits as you type (as above); Manual lets you type freely and changes nothing until you press **UPDATE** (the box shows "edited · press UPDATE" while edits wait). The choice is remembered.
- **Auto Captions - Insert a caption.** Move the time indicator to where a new caption should go and press **CHECK TIMELINE**: the panel reads the Dala captions in the comp and tells you where the new caption fits - after the speech of the caption before it, on the voice heard there (snapped to where that voice starts) or at the time indicator when nothing is spoken there. Press **ADD NEW LAYER**, type the caption, press **UPDATE**: the new layer is inserted in place, timed to that voice (its reveal is full when the voice ends; with no voice, timed to its length), the later captions are numbered up and the captions on both sides are rebuilt so they fit around it. Works for Woodl Style and the Text Preset families, and after After Effects restarts: each build is remembered in `%APPDATA%\DalaSuite\captions`, so CHECK TIMELINE brings its lines back into the box.
- **GENERAL - Anchor Point and Align in the panel.** No separate windows: a 3 x 3 Anchor Point pad and an Align pad (top, middle, bottom, left, centre, right) sit right in the card, each with its own **Lock**. Locked, the anchor stays on its point of the layer and the alignment stays to the composition when the text is edited, the shape changes or keyframes change. Turning a Lock off releases the selected layers without moving them.
- **Clean Up** (GENERAL): frees the space older projects take - the After Effects disk cache (purged by After Effects itself), the media cache of footage the open project does not use (wherever each Adobe version keeps it), other projects' auto-saves, Dala Suite files made for other projects (SFX, stems, link downloads) and Dala's temporary files. SCAN shows each group with its size; nothing goes until you press CLEAN UP and confirm. Everything the open project uses is kept; caches and temp files are deleted (they are rebuilt when needed), auto-saves and Dala files go to the Recycle Bin. Project files, footage and models are never touched.
- **New GENERAL tools:** **Gradient Lock** (Gradient Ramp, 4-Color Gradient and shape gradient fills keep their place inside the layer during later edits), **Organise Project** (comps, precomps, video, audio, images and solids into folders - only the folders change, links stay), **Gap Finder** (empty stretches between clips; close all or the ticked ones, the later clips move back), **Black Frames** (frames no clip covers, also inside precomps, and black pictures in the footage - listed and marked on the timeline), **Sequence Layers** (the selected clips back to back in their layer order, lengths kept), **Select** (every video, audio, text, shape, adjustment, solid, null, camera, light or precomp layer of the active comp in one click; **CHECK COMPOSITION** lists what the comp has, missing types are greyed out). **Arrange Clips** is now **Beat Clips Arranger** (same beat-marker arrangement).
- **Adjustment, Solid and Null for many layers:** with several layers selected you get one new layer FOR EACH selected layer, right above it, with its own in / out points (they share one solid in the project). Each layer is parented to its own null without moving (keyframes kept). Tested with 1, 10 and 50 layers.
- **Fixed: pre-compose cut the last frames / black frames between clips.** A scripted pre-compose gives the new comp the footage's frame rate (25 fps clips in a 30 or 23.976 fps comp -> a 25 fps precomp), so its length was rounded to the wrong frames: the clip's last frame was cut and a black frame showed before the next clip (Cut to F, Precomp, Precomp each, Auto Tracker). Precomps now take the comp's frame rate and every time is a whole frame of the comp - rendered frames are identical to the timeline before pre-composing, with no extra frames added.
- **Fixed (panel layout):** GENERAL controls stay inside the card at every panel width; long tool names wrap onto two lines instead of being cut.

## What's New in 2.0.5

- **MUSIC STEMS** (new tab: sidebar **Stems**, Home card **MUSIC STEMS**): select a song (an audio file, a clip with sound or a precomp) and press **EXTRACT STEMS** - Dala splits it into **Drums, Bass, Guitar, Piano and Other** on this PC with the HT-Demucs 6-stem model and adds the five stems to the comp as audio layers right above the song, lined up to the sample. Vocals are never extracted. **Whole layer** or **Work area**, optional **Mute the original layer**, running it again replaces the earlier stems. See feature 12.
- **6-stem model install:** the model (136 MB, MIT) is pinned by size and SHA-256. A copy already on the PC is reused instead of downloaded (the Hugging Face cache, Downloads, Desktop, Documents are searched; **USE FILE** takes a copy anywhere else) - only after its checksum matches. Otherwise it downloads with exact MB progress, resumes after an interruption, is re-verified on every run and repaired if damaged. Runs on the existing speech engine: nothing else to install.
- **SFX EXTRACTOR** (new tab: sidebar **SFX**, Home card **SFX EXTRACTOR**): select a movie clip with 5.1 sound and press **EXTRACT CENTRE** - Dala reads the file's channel layout, shows all six channels (L, R, **C**, LFE, Ls, Rs), takes **only the Centre channel** (the original dialogue with the punches, kicks, sword clashes, impacts, whooshes and footsteps - no music or ambience from the other channels) with FFmpeg, saves it as a mono WAV and adds it above the clip, timed exactly like the clip. Not a downmix, no AI. Stereo / mono / unlabelled audio gets a clear message instead of a guess. See feature 13.
- **Why the Centre layer matters in After Effects:** tested in After Effects 2025, a 5.1 clip's own sound does not give you the dialogue: AE plays only channels 1-2 of 5.1 PCM (no Centre at all), plays DD+ (E-AC3) sound from the wrong places and plays no sound at all from Dolby Digital in MKV. The Centre layer follows the file's real timing, in sync with the picture, in all of these.
- **Fixed (speech engine install):** a Windows path that is too long for a DLL was reported as a missing Visual C++ Runtime; it now names the real cause.

## What's New in 2.0.4

- **Caption styles** - Auto Captions has a new **CAPTION STYLE** tab: pick **Woodl Style** (the original Dala caption, renamed), **Text Preset 1** (6 looks: questions, shouts, a hero title) or **Text Preset 2** (3 kinetic looks: each part of the line pops in as it is spoken), made from `txt pjf 1.aep`. Each style has an animated preview, a description and a "looks" count; the chosen style is shown under the caption lines. See feature 8.
- **Caption director (Smart):** for every line Dala decides which look fits, the way an editor would: a question gets a question look, an exclamation, a name or a word said loudly or stretched gets a strong look (the big hero title is kept for the real moments and spaced out), calm lines get calm looks, the same look never plays twice in a row, and long lines go to looks with room for them. The words are poured into the look's parts in reading order - the emphasised word in the big part, a phrase never cut in an odd place - and each part appears when its words are spoken. **In order** cycles through the looks instead (1, 2, 3, 1...). It runs on this PC in milliseconds: no internet, no AI service, no account.
- **What a style needs:** the style tab checks the plug-ins and fonts a style uses and names anything missing (Sapphire, Boris FX BCC, fonts); Deep Glow falls back to After Effects' own Glow. **Animation Composer is not needed** - the looks' Animation Composer motion is stored as ordinary keyframes.
- **Spoken Tamil and Hindi** (new option **Spoken Tamil / Hindi**, on by default): Tamil captions are written the way Tamil is spoken in films and everyday talk (நீங்க, வாங்க, இருக்கு, போறேன், மண்ணுலதான்) instead of formal written Tamil (நீங்கள், வாருங்கள், இருக்கிறது, போகிறேன், மண்ணில்தான்); Hindi uses everyday words instead of Shuddh Hindi. Tanglish and Hinglish follow (*neenga*, *poren*, *vandhuttaan*). Hinglish now writes English words the English way (*coffee*, *choice*, *tiger*, *film*, *free*) and fixes word-final *ph* (*saaf*, *taraf*, not *saaph*).
- **Better translations, nothing skipped:** captions in another language are now translated from the transcript by **MADLAD-400 3B** (Google, Apache 2.0 - fine for a paid product), a whole sentence at a time. It replaces Whisper's own translation for Tamil / Hindi to English (it listened a second time, mistranslated spoken Tamil and invented lines on Hindi film audio) and the NLLB-200 translator (non-commercial licence, set up with PyTorch on the PC). Tamil to English is about 5x faster (one listening pass instead of two). The translator is downloaded once, about 3 GB, the first time a translation is asked for.
- **Fixed: Hindi speech skipped** - a spelling hint made Whisper jump over whole stretches of Hindi film dialogue (37 s of the 2.4-minute test clip had no captions). Hindi now gets no hint, and a hinted pass (Tamil) is checked: speech left without words is heard again and filled in.
- **Fixed (Layer Setups and caption styles):** a property whose expression uses its own value (for example *Fade In+Out - frames*) was saved with the expression's result instead of its own value, so such a layer could come back invisible.
- **Fixed (narrow docked panel):** the From / To language buttons were cut off on both sides (now *Detect...* with the full name on hover), and **GENERATE CAPTIONS** ran past the panel edge (the two buttons now stack).

## What's New in 2.0.3

- **Beat Marker rebuilt on a drums track** - the "render the audio, split out the drums, mark the hits on the drums waveform" method, done on this PC: Dala extracts the drums with the HT-Demucs FT drums model (ONNX, 166 MB, downloaded once and checksum-verified), finds the beat on that drums track (onset strength -> tempo -> dynamic-programming beat tracker, each beat snapped to its drum hit) and marks it. New **Drum hits** option marks every clear kick / snare hit, also off the beat. See feature 11.
- Beat Marker **Selected Layer** (markers on the selected audio layer) or **Composition** (the comp's whole mix, markers on the composition's own timeline). Both analyse the work area. Optional **drums track**: the extracted drums as a layer (audio off) to check the markers against its waveform.
- Drum model download: exact progress (never above the total), resume after an interruption, verified (SHA-256) before it is used, re-checked on every run and repaired if damaged, **DOWNLOAD / RESUME / REPAIR** button, clear errors for network, disk and permission problems.
- New **GENERAL** tab (sidebar **General**, Home card **GENERAL**): the everyday editing tools **Curves** (ease graph editor + library), **Text**, **Precomp**, **Precomp each**, **Decomp**, **Copy fx**, **Paste fx**, **Duplicate**, **Null**, **Solid** (colour picker), **Adjust**, **Link** (import a video from a TikTok / YouTube / Instagram / Pinterest / X link), **Beat Checker** and **Arrange Clips**. See feature 10.
- **One small status message:** every tab now shows a single compact message at the bottom (a new one replaces the old one; long text is cut to two lines, hover for all of it, click to dismiss) instead of a growing stack of boxes that covered the panel.
- **Text Presets** removed (the `presets/text` category and its navigation entry, Home card and library section).
- **Donate** button next to the Reload icon (opens https://buymeachai.ezee.li/dala_aep in your browser).

## What's New in 2.0.2

- **Version error fixed:** the caption style used to ship as an After Effects project (`dala-default.aep`, saved in After Effects 2026), which older versions refuse to open ("...created with After Effects version 26.0 / 24.0..."). The style is now a version-independent layer recipe (`captions/styles/dala-default.json`) that Dala rebuilds in whatever After Effects is running. See *After Effects Compatibility*.
- **Speech model downloads** rebuilt: every model file is pinned (size + checksum), downloads resume where they stopped, a second download of the same model is blocked, **RECHECK** verifies every file and **DOWNLOAD / RESUME / REPAIR** fetches only what is missing or damaged. Fixes the progress that showed e.g. "5.97 GB of 3.09 GB" (the old download counted Hugging Face's duplicate cache copies). See feature 8.
- **Layer Setups** (sidebar **Setups**, Home card **LAYER SETUPS**): save selected layers / precomps under a name and apply them again in any project. See feature 9.
- **Unprecompose** (Home card **UNPRECOMPOSE**). See feature 10.
- **Audio Tools** (sidebar **Audio**, Home card **AUDIO TOOLS**): **Beat Marker** and **Vocal Remover** (Demucs v4). See feature 11.
- **Auto Tracker** now has two separate start buttons: **TRACK WITH CUT 2 F** and **TRACK WITHOUT CUT 2 F**.
- Presets that need a third-party plug-in which is not installed are no longer applied half-way: Dala names the missing plug-in instead.
- **Auto Captions** (new view: sidebar **Captions**, or the **AUTO CAPTIONS** card on Home): listens to the selected audio layer or precomp on this PC (Whisper) and builds captions from your own text preset. Google Translate-style **From / To** languages (Tamil, English, Tanglish, Hinglish; From can detect the language), **TEST AUDIO** to preview and edit the lines, each caption held until the next line is spoken, and **CLEAR CREATED LAYERS**. See feature 8 below.
- **Auto Captions setup** works on a fresh Windows PC: one click installs a private, version-pinned speech engine (Python included). It no longer depends on the customer's own Python, which failed with Python 3.15 (no speech-engine packages exist for it yet), with Python installed for all users (no write access) and with unpinned package versions.
- **Auto Tracker** (new view: sidebar **Tracker**, or the **AUTO TRACKER** card on Home), followed automatically by **Cut to F** on every tracked clip. See feature 7 below.
- Auto Tracker framing: face held on the exact comp centre (Proportional Grid centre) on both axes, per-frame zoom computed from the tracked subject (Max zoom limit), letterbox bars and empty areas never shown.
- Auto Tracker tracking works like a manual head track: a real After Effects tracker on every tracked layer (Motion Trackers > Tracker 1 > Track Point 1 with Feature Center / Confidence / Attach Point keys) applied like Stabilize Motion > Apply X and Y (Anchor Point keys) and centred with Position. Fully automatic: Dala tracks the nose with a medium feature region (sub-pixel) and builds the tracker.
- Auto Tracker preview: the panel renders in software (CEF switches), fixing the preview flashing black in a docked panel.
- Auto Tracker panel: detection and tracking run on a background worker and After Effects is never blocked, so the panel no longer flickers and the preview never goes black; the preview shows tracking live.
- **Manifest fix:** the CEF switches are now declared in `<CEFCommandLine>`. Version 2.0.1 placed them in a
  `<CEPEngine><CommandLine>` block, which CEP does not read, so the panel never had Node.js on CEP 8+
  (After Effects CC 2018 and newer). That is why an earlier Auto Tracker attempt failed with
  *"The Auto Tracker needs the panel's Node.js runtime"*. The 2.0.2 Auto Tracker does not need Node.js at all.

---

## After Effects Compatibility

- **Supported:** After Effects 2020 (17.0) and newer on Windows 10 / 11 (64-bit). The manifest declares `AEFT [17.0,99.9]` with CSXS 9.0 (CEP 9, Chromium 61 / Node 8 in AE 2020), and the panel avoids newer browser features (flex `gap` has a fallback, no `inset`, no Node 14+ APIs).
- **Tested:** After Effects 2025 (25.6) - every 2.0.2 feature, and in 2.0.3 Beat Marker (both modes), GENERAL (every button, through the panel), Donate, the removed Text Presets and an Auto Captions build, in 2.0.5 Music Stems and SFX Extractor through the panel (see features 12 and 13), and in 2.0.4 Auto Captions through the panel (every caption style, Smart and In order, Tamil to Tanglish / Tamil / English, Hindi detected to Hinglish, Spoken Tamil / Hindi on and off, Clear, a comp without audio) with every look checked frame by frame against its design; After Effects 2026 (26.0) - Auto Tracker, Auto Captions (2.0.2). After Effects 2020-2024 were **not** tested on a real install; support there rests on a code audit (ES3 ExtendScript, scripting APIs guarded or with fallbacks) and is not guaranteed.
- **Why the old "created with After Effects version ..." error happened:** `captions/styles/dala-default.aep` was saved in After Effects 2026; After Effects never opens projects saved by a newer version. No `.aep` / `.aet` ships with 2.0.2 or 2.0.3. The bundled `.ffx` presets are not version-locked, but every one needs a third-party plug-in: Sapphire (S_Shake, S_Flicker, S_BlurMoCurves - Shake 1/5, c-c shake1, Premium Shake + Zoom, all Zoom presets), Video Copilot Twitch (Shake 2-4), Boris FX BCC (Lens Blur, Fast Film Glow - the lens-blur and seamless shakes) and Twixtor (all Twixtor presets). Dala now names a missing plug-in instead of applying a broken preset.
- **Version-dependent details** (handled automatically): caption ALL CAPS uses `fontCapsOption` (After Effects 24+) and otherwise upper-cases the text; Deep Glow falls back to the built-in Glow when it is not installed; text and layer settings newer than the running After Effects are skipped with a note.
- Older than 2020 (CC 2019 and earlier) is not supported.

---

## Default Presets Library (Google Drive Structure)

Dala Suite ships with the complete default preset library from Google Drive organized by category folders:

- **`presets/shake/` (10 presets):**
  - `Individual Clip Shake 1.ffx`
  - `Individual Clip Shake 2.ffx`
  - `Individual Clip Shake 3.ffx`
  - `Individual Clip Shake 4.ffx`
  - `Individual Clip Shake 5.ffx`
  - `Premium Individual Clip Shake + Zoom in.ffx`
  - `c-c shake1.ffx`
  - `hard shake+ lens blur.ffx`
  - `seamless shake.ffx`
  - `shake+lens blur.ffx`
- **`presets/twixtor/` (4 presets):**
  - `reverse-twix.ffx`
  - `twixtor 240 speedramp.ffx`
  - `twixtor dialogue.ffx`
  - `twixtor mid fast speedramp.ffx`
- **`presets/zoom/` (3 presets):**
  - `aggressive ZOOM IN.ffx`
  - `microwave zoom.ffx`
  - `myzoom.ffx`

---

## Fully Dynamic Preset Sections & Categories

The extension **never hardcodes preset category names** anywhere in the frontend or ExtendScript host. The folder structure on disk is the sole source of truth:
1. **Dynamic Folder Discovery:** On load and reload, `presetEngine.jsx` scans all subdirectories inside the presets folder.
2. **Dynamic Preset Library Sections:** In the Preset Library view, presets are rendered in distinct sections grouped by their actual folder names on disk (e.g. `📁 Shake`, `📁 Text`, `📁 Twixtor`, `📁 Zoom`), each with a preset counter badge.
3. **Folder Renaming:** If you rename a folder on disk (e.g. `shake` &rarr; `My Shakes`), Dala Suite automatically detects the new folder name upon reload:
   - The section header in the Preset Library shows **My Shakes**.
   - The filter tabs show **My Shakes**.
   - The navigation tab and Home card show **My Shakes**.
   - The Shake panel updates its title to **My Shakes Presets** and apply button to **APPLY MY SHAKES**.
4. **Folder Addition & Deletion:** Adding a folder (e.g. `blizzards` or `transitions`) instantly creates a dynamic navigation item, home card, library section, and interactive category view upon clicking reload. Removing a folder cleanly unmounts it from the UI.
5. **Dynamic Category View:** Discovered categories (like `Text`, `Blizzards`, or custom packs) open in dedicated category views with individual preset selection, keyframe stretch toggles, and direct application.

---

## Core Feature Set

### 1. Cut To F (Non-Destructive 3-Layer Split)
Splits each selected timeline layer into **3 separate timeline layers**:
- **Layer A (First Frame):** Exactly 1 frame duration (at layer start).
- **Layer B (Middle Section):** Starts after 1st frame, ends before last frame.
- **Layer C (Last Frame):** Exactly 1 frame duration (at layer end).
- **Source Footage Unmodified:** Original footage is never trimmed, shifted, or deleted. The 3 layers seamlessly reproduce the exact original visual sequence.
- **Independent Multi-Layer Support:** Multiple selected layers are split simultaneously and independently in a single undo group.

### 2. Twixtor Dialog
- Applies `twixtor dialogue.ffx` preset.
- Inspects effect properties to set **Input: Frame Rate** to the selected dropdown value (`23.976`, `24`, `25`, `29.970`, `30`, `60`, `120`).
- Automatically targets and unchecks the **"In FPS is Out FPS"** checkbox (`setValue(0)`).
- Wraps execution in a single undo group per layer.

### 3. Twixtor Speed (Multi-Layer Independent Execution)
- Applies `twixtor mid fast speedramp.ffx`, `twixtor 240 speedramp.ffx`, or any discovered Twixtor preset.
- Sets Input: Frame Rate and unchecks "In FPS is Out FPS".
- **Zero Playhead Bias & Safe CTI Clamping:** Cues composition time directly to each layer's own `inPoint` prior to preset application safely clamped within `[0, comp.duration]` (`$._dalaSuite.setSafeCompTime(comp, timing.safeCtiTime)`). Slipped clips with negative `inPoint` values (e.g. `-0.1s`) or times beyond composition duration are automatically validated, completely eliminating the After Effects error: `Unable to set "time". Value -0.1 out of range 0 to 10800`.
- **Independent Keyframe Stretching:** Time-stretches newly created keyframes to match each layer's duration independently:
  - Keyframe 1: Exactly at layer `inPoint`.
  - Keyframe 2: Exactly at 50% layer duration (`inPoint + (outPoint - inPoint) * 0.5`).
  - Keyframe 3: Exactly at layer `outPoint`.
- Velocity curves and ease parameters are strictly preserved.

### 4. Dynamic Zoom Centering
- Applies Zoom presets (`myzoom.ffx`, `microwave zoom.ffx`, `aggressive ZOOM IN.ffx`).
- Automatically reads the active composition dimensions and computes dynamic center coordinates (`comp.width / 2`, `comp.height / 2`).
- Adapts anchor points and position centers perfectly for any aspect ratio (16:9 1920x1080, 9:16 1080x1920, 1440x1600, 4K, square 1080x1080).
- Uses safe playhead navigation and stretches newly created keyframes across each layer's duration.

### 5. Shake Presets
- Dynamically discovers all shake presets from disk (11 presets included).
- Safe playhead navigation and optional keyframe stretching toggle to stretch shakes across full layer duration.

### 6. Dynamic Presets Browser & Configurable Root Directory
- **Dynamic Category Sections:** Groups presets into collapsible/scrollable sections by category folder.
- **Configurable Root Directory & Folder Name:** Allows editors to configure custom preset directories or folder names via the UI or `config/settings.py` / `config/settings.json`.
- **Search & Filter:** Instant search filtering across preset names and categories.
- **Safe Keyframe Stretching:** Remaps newly applied preset keyframes from each layer's `inPoint` to `outPoint` (supporting negative inPoints) without altering property values or bezier easing curves.

### 7. Auto Tracker (Face / Point Centering) + Cut to F
Centres a face or any point in every shot of the selected footage (or pre-comp) layers and then runs CUT TO F on every tracked clip - fully offline inside After Effects.
1. **Select** one or more layers and click **TRACK WITH CUT 2 F** (track, then Cut to F on every tracked clip - step 6) or **TRACK WITHOUT CUT 2 F** (track only: the clips are not split and get no Cut to F).
2. **Finding shots:** After Effects renders small analysis frames in the background (the panel polls for them, so After Effects is never blocked); the panel splits each layer into shots at the exact cut frame and measures any letterbox bars.
3. **Pick per shot:** detected faces are boxed - click one. Or **Track a point** (click the subject, size it with -/+, **Track this point**), drag the strip to another moment, or **Skip shot**. Optional *Auto-pick the largest face*.
4. **Tracking** works like the manual head-track workflow (Tracker > Stabilize Motion, track point on the nose, Analyze, Apply X and Y), and leaves the same thing on the layer: **Motion Trackers > Tracker 1 > Track Point 1** with Feature Center, Confidence and Attach Point keyed on every frame, and the **Anchor Point** keyed to the track point (what Apply X and Y writes), with Position holding the comp centre. Dala tracks the nose itself - a medium feature region (half a face wide: nose, inner eyes, upper lip) matched in every frame by normalised cross-correlation with sub-pixel positioning, adapting the feature below 80% confidence like After Effects' tracker; the search follows the head's motion, YuNet re-finds the face after an occlusion and checks every ~0.5 s that the point is still on the face. It runs on a background worker, forward and backward from the picked frame, shown live in the preview. **Smoothness 0** (default) applies the track as it is, like Apply X and Y; higher values average the motion.
5. **Framing:** the face (or point) is placed on the exact comp centre - the central intersection of the Proportional Grid - horizontally and, with *Centre vertically* (on by default), vertically, on every frame. The zoom is computed per frame from the tracked subject: the smallest scale at which the picture (inside any letterbox / pillarbox bars) still fills the comp with the subject on the centre. It is eased over ~0.6 s so it never pumps, kept steady when it would barely change, and limited by **Max zoom** (default 250% of the size that just fills the comp). Only past that limit is the subject kept as close to centre as possible instead: **letterbox / pillarbox bars and empty comp areas never show**. Motion: **Both**, **X only** or **Y only**; Smoothness slider.
6. **Cut to F after tracking** (only with **TRACK WITH CUT 2 F**): every tracked clip gets frame blending (Pixel Motion) and motion blur, is split into First 2 frames / Mid / Last 2 frames with frame blending off on the 2-frame ends and on in the middle, and the three sections are pre-composed exactly like the CUT TO F tool ("<clip> [Cut to F]", same timing and layer order; the pre-comp's frame blending and motion blur switches are on). Clips shorter than 5 frames only get frame blending + motion blur.
- One **Ctrl+Z** undoes the whole run (tracking, splits and Cut to F). **REMOVE TRACKING** restores the original position, scale and motion blur of selected tracked layers - also inside the Cut to F pre-comps - and removes the Motion Tile.
- Other options: split layers at shot cuts, remove letterbox bars, mirror edges (Motion Tile; only real picture is ever mirrored), motion blur, Best / Fast analysis.
- Requirements: *Edit > Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network* must be on (analysis frames go to the system temp folder). No ffmpeg, no internet. Node.js is used for file checks when the panel has it, otherwise After Effects is asked.
- Verified in After Effects 2026 on clips from the AK clip set (9:16 and 16:9 comps, letterboxed 2.39:1 footage, multi-layer runs, undo, Remove tracking inside Cut to F pre-comps). Face detection: YuNet (OpenCV Zoo / libfacedetection), run by a small pure-JavaScript engine bundled with the panel - see `THIRD_PARTY_NOTICES.txt`.

---

### 8. Auto Captions (speech to captions in your caption style)
Captions synced to the dialogue, built from the comp's audio in the caption style you pick.
- **CAPTION STYLE** tab: **Woodl Style** (one clean line per caption, revealed as it is spoken), **Text Preset 1** (6 looks) or **Text Preset 2** (3 looks). The big preview plays the style; click a card to choose it. For Text Preset 1 / 2, **Smart** lets Dala choose the look for each line (questions, shouts, names and loud or stretched words get the strong looks, the hero title only for the real moments, never the same look twice in a row) and **In order** uses the looks one after another. The note under the cards names any plug-in or font the style uses that is not installed on this PC.
1. Open the comp, set the **work area** to the part to caption and **select the dialogue audio layer or precomp**, so music and sound effects are ignored (*Only the selected layers' audio*, on by default; with nothing selected the whole comp is used).
2. Pick the languages in the Google Translate-style bar: **From** (what is spoken: *Detect language*, Tamil, English, Tanglish, Hinglish) **⇄ To** (what the captions say: Tamil, English, Tanglish, Hinglish). *Detect* shows the language it heard, e.g. "Tamil - detected". The ⇄ button swaps the two.
3. **TEST AUDIO** listens to the selected layer / precomp and fills the two panes - what was said and the captions, one line per caption - without touching the comp. Edit the lines freely - change words, add, split or join lines, any length; an emptied line drops that caption. Each line is timed from the words it shares with the speech.
4. **GENERATE CAPTIONS** creates one text layer per caption (`CAP 01`, `CAP 02`...), each a copy of the preset layer. When the audio has not changed since TEST AUDIO, the recognition (and your edits) are reused. After GENERATE, editing the box updates the caption layers a moment after you stop typing (a changed line is rebuilt in its place) - or, with **Layers: Manual**, when you press **UPDATE**. **Insert a caption:** put the time indicator where it goes, **CHECK TIMELINE**, **ADD NEW LAYER**, type it, **UPDATE** - it is timed to the voice there and the captions around it adjust.
   - **Timing:** each layer starts with its reveal, 0.47 s (the preset's lead) before its line is spoken, and runs until the next line starts - so one line sweeps out while the next one reveals - (the last one holds 1 s after its speech, inside the work area). One caption per spoken phrase (the words between two pauses) when it fits on two lines; a longer one is split into balanced captions, never leaving a lone word. Word times are checked against the waveform (speech detection), so a caption never starts in the silence before its line.
   - **Keyframes** stay the preset's own and individually adjustable, placed like the timing reference: the fade-in starts with the layer (the same lead before the speech) and is full when the line has been spoken; the fade-out starts where the preset starts it within the fade-in (77 % of the way) and ends just before the next line's speech; the tracking expand runs the whole layer and a little past its end. A long pause holds the whole line (the fade-out waits until 2.5 s before the end).
   - **Languages:** Tamil and English come straight from Whisper; Tanglish and Hinglish are the spoken Tamil / Hindi written in English letters, the casual way people text (e.g. *poi un appaavai koottittu vaa*, *phir milenge*); every translation (Tamil or Hindi to English, English to Tamil...) is made from the transcript by the offline MADLAD-400 translator, a whole sentence at a time, each word timed over the speech it translates.
5. **CLEAR CREATED LAYERS** deletes only the caption layers Dala created in the comp (other layers are never touched). **One Ctrl+Z** undoes a whole build.
6. Options: accuracy (Fast / Balanced / Best = Whisper small / medium / large-v3), position (Upper / Center / Lower), size, words per caption, only selected layers' audio, **Spoken Tamil / Hindi** (the language as people speak it, on by default; off = formal written language), keep punctuation, replace previous captions, use the graphics card.
- Captions in Tamil script automatically use Nirmala UI (the preset font has no Tamil letters).
- Woodl Style lives in a project folder **Dala Captions (styles)**; Text Preset 1 / 2 captions are precomps (`CAP 01 · txtp2_3` ...) in a folder **Dala Captions**. Both are safe to delete; **CLEAR CREATED LAYERS** also removes the caption precomps nothing else uses.
- **Text Preset 1 / 2 need**, for the exact look: Boris FX Sapphire (Text Preset 1: S_TextureFlux / Folded / Plasma; Text Preset 2: S_WipeLine), Boris FX BCC Halftone (Text Preset 2) and the fonts Coolvetica, HambuRadul Italic, Lucida Calligraphy, MV Boli, Times New Roman Bold (Text Preset 1) and Arial Rounded MT Bold, Game Of Squids, Utsaah Bold (Text Preset 2). Without a plug-in that effect is left out; without a font After Effects substitutes one. Deep Glow falls back to the built-in Glow. Animation Composer is not needed.
- **Speed note:** on a 4 GB graphics card After Effects and the speech engine share the GPU, so recognition can take longer while After Effects is busy rendering; it never fails because of it (36 s of Tamil: about 30 s to 2 min on a GTX 1650).
- **Requirements:** Windows 10/11 (64-bit) and an internet connection for the one-time downloads. **Nothing has to be installed by hand** - no Python, FFmpeg or terminal commands. The first time, the panel shows **INSTALL SPEECH ENGINE**: it downloads Dala Suite's own private Python 3.11.9 (the official python.org embeddable package) and the speech engine (faster-whisper with pinned, SHA-256-checked packages, about 200 MB) into `%LOCALAPPDATA%\DalaSuite\engine` - no admin rights, nothing added to PATH, and a Python the user already has is never touched or used. A failed or cancelled install leaves nothing half-done (press **TRY AGAIN**); a damaged engine shows **REPAIR SPEECH ENGINE**. The last install's output is kept in `%LOCALAPPDATA%\DalaSuite\install-log.txt` for support. The Whisper speech model (Systran/faster-whisper-*, 0.5 / 1.5 / 3 GB) is downloaded once - from the model row under the language bar (**DOWNLOAD**) or on the first caption run - into `%USERPROFILE%\.cache\dala_whisper\models\<name>`. Every file is pinned to a size and checksum (`whisper/models.json`): an interrupted download shows **RESUME** and continues where it stopped, a damaged file shows **REPAIR** and only that file is fetched again, **RECHECK** re-verifies every byte, a second download of the same model waits for the first, and disk-space, network and permission problems are reported in plain words. A model downloaded by an earlier Dala Suite is reused (checked first) and its old copy removed. NVIDIA GPUs: **ENABLE GPU** downloads cuBLAS 12 once (about 550 MB) into `%LOCALAPPDATA%\DalaSuite\cuda12`; without it everything runs on the CPU. The first translation downloads the MADLAD-400 3B translator once (about 3 GB, pinned and checksum-checked like the speech models, resumes after an interruption) into `%USERPROFILE%\.cache\dala_whisper\models\madlad-3b`; it runs on the CPU and needs about 3.5 GB of free RAM while it translates. The NLLB-200 translator of 2.0.2 / 2.0.3 is deleted then. *Allow Scripts to Write Files and Access Network* must be on. macOS is not supported by the speech engine yet.
- Verified in After Effects 2026 with Tamil dialogue in a precomp (1080x1920, 30 fps): large-v3 on a GTX 1650 detects and transcribes the 36 s test dialogue in about 35 s (Tamil, Tanglish), about 50 s for English captions from Tamil, about 20 s from English audio to Tamil / Tanglish / Hinglish; building the layers takes a few seconds. Re-tested in After Effects 2025 (25.6): engine install, model download / cancel / resume / recheck, and a 9-caption build from the version-independent style recipe.
- **Caption font:** the default style uses **Coolvetica**; when it is not installed After Effects substitutes a font. Its Deep Glow is replaced by the built-in Glow when Deep Glow is missing.

### 9. Layer Setups (save and reuse multi-layer arrangements)
Sidebar **Setups**, or the **LAYER SETUPS** card on Home.
1. Select the layers or precomps, type a **Name** and press **SAVE SELECTED LAYERS**.
2. **APPLY** builds the setup again in the active comp (a new comp of the saved size when none is open), at the **Time indicator** or at the **Original times**. Precomps are rebuilt with everything inside them, in a project folder "<name> (Dala setup)".
3. **RENAME** and **✕** (delete, with confirmation) manage the list.
- What comes back: layer order, timing, transforms, keyframes (with eases and spatial tangents), expressions, effects, masks, text (font, style, animators), shapes, parenting, track mattes, blending modes, switches and markers.
- Footage whose file is gone is replaced by a placeholder solid of the same size, and the result names it; effects from plug-ins that are not installed are skipped and named.
- Setups are stored as files in `%APPDATA%\DalaSuite\LayerSetups` and survive restarts and updates (tested: still listed and applied after restarting After Effects).

### 10. GENERAL tab
Sidebar **General** (or the **GENERAL** card on Home): one card of icon buttons (hover for a tooltip; the line under them describes the hovered tool). Results show as the panel's one small status message. The **options** button (top right) holds the settings below. Buttons are defined in `client/js/general/generalUI.js`; the host side is `host/editTools.jsx` (Edit tools), `host/unprecompose.jsx` (Decomp) and `host/generalTools.jsx` (beat tools). Every action is one **Ctrl+Z**.

- **Curves** (opens its own page; the arrow at the top goes back): a graph editor for the ease between keyframes. **Value** graph (default) or **Speed** graph like After Effects'. Drag a handle (Shift: flat, Ctrl: 10x finer); in the Speed graph sideways = influence, Alt + up / down = speed, and the curve itself can be dragged. Scroll to zoom (Ctrl: time axis only, Shift: value axis only), drag the empty space to move, double-click it (or the fit button) to fit; the invert button draws the value graph going down. Double-click a handle to type its **influence** and **speed** (Keyframe Velocity); click the four numbers to type them. **Apply** sets the curve on every selected pair of keyframes (no keyframes selected: the Time Remap keys of the selected layers), with the speeds measured along the motion path like After Effects, so the result matches AE's own graph. **Read keys** loads the ease of the selected keyframes and shows their values, duration, influence and speed (with several pairs, < > steps through them). **Save** keeps a curve in your library (double-click to rename, x to delete); click a library curve to load and apply it. Options: apply while editing, bring back removed built-in curves, delete all your curves.
- **Text**: a centred white text layer ("Your text", size = comp height / 9) above the selected layer.
- **Precomp**: the selected layers go into a new comp, trimmed to their length (the precomp starts where they start). With several layers Dala asks once: **Each layer on its own** or **All together** (remembered; change it in the options). The precomp layer gets the composition label colour.
- **Precomp each**: every selected layer into its own precomp, named after it, trimmed to its length.
- **Decomp**: the layers of each selected precomp come back into this comp in its place, with their order, timing, transforms, effects, masks, expressions, parenting and animation. When the precomp layer is moved / scaled / rotated, a null "<name> (transform)" carries that, so nothing moves on screen. The precomp layer is removed; what cannot move onto separate layers (its opacity, effects, masks, blending mode, track matte, time remapping, time stretch) is named in the message as "not kept". Option: also delete the precomp from the project once nothing uses it.
- **Copy fx** remembers the effects of the selected layer (values, keyframes, expressions) and its look (blend mode, opacity, motion blur, scale, rotation). **Paste fx** puts them on every selected layer. Options: effects, replace existing effects, blend mode / opacity / motion blur, scale and rotation; animation **Off**, **Keep** (same timing from each clip's start) or **Fit to clip** (default: keyframes stretch or squeeze to each clip's length, the speed graph keeps its shape).
- **Duplicate**: an independent copy of the selected precomp (the comp itself is duplicated, "<name> copy"), so editing inside it never changes the original. Options: **New layer** (a new layer with the copy, default) or **In place** (the selected layer switches to the copy); **Nested precomps too** (default on).
- **Null**: on the selected layer (where it is on screen), named "<layer> · control"; the selected layers are parented to it without moving (the top of each parent chain; the null takes the parent they shared).
- **Solid**: a colour picker first (colour wheel, brightness bar, 12 quick colours, the last 6 used, hex code; double-click a colour to create at once), then a comp-sized solid. The tile's dot shows the current colour.
- **Adjust**: a comp-sized adjustment layer.
- Text, Solid, Null and Adjust go directly above the top selected layer; **Match selected layer** (option, on by default) gives them the selected layer's in / out points. An optional **Name** in the options is used for the new layer.
- **Link**: paste a TikTok, YouTube, Instagram, Pinterest or X link (a link copied in the browser is filled in when the panel can read the clipboard). The video downloads (H.264 MP4 up to 1080p) into `Downloads\Dala Suite\From links` and lands in the comp at the playhead, above the selected layer, scaled down to fit when it is bigger than the comp (no comp open: a new comp is made for it). **Sound only** gives a WAV. Pinterest picture pins come in as the picture. The downloader is **yt-dlp**, fetched the first time from its GitHub release (SHA-256 checked) into `%LOCALAPPDATA%\DalaSuite\tools` and updated once a day; **FFmpeg** (31 MB, the pinned imageio-ffmpeg wheel from PyPI, SHA-256 checked) is fetched once to join picture and sound. When a YouTube download fails because YouTube asks for a JavaScript runtime, Link fetches **Deno** once (43 MB, pinned release 2.9.7, SHA-256 checked) into `%LOCALAPPDATA%\DalaSuite\tools\deno` and tries again; from then on yt-dlp always uses it for YouTube. Sound is stereo. Click Link again during a download to cancel it: the download stops and its partial files are deleted. Only import videos you are allowed to use.
- **Beat Checker**: finds the beat markers (a selected layer's markers, else the composition markers, else a layer with Beat Marker's markers, else the audio layer with the most markers) and puts a coloured, comp-sized solid from each marker to the next, colours alternating, at the top of the comp. Play the comp: every colour change should land on a beat. Footage and audio are not touched; running it again replaces the previous check.
- **Arrange Clips**: the footage / precomp clips (the selected ones, or all of them) are placed one per beat interval in their current order (start time, then stacking order): each starts on a beat marker and is trimmed to end on the next one, keeping its own trim and keyframes. A clip shorter than its interval ends early (named in the message); extra clips or extra beats are reported. Audio, text, shape, solid, null, adjustment layers and the Beat Checker solids are never moved.

### 11. Audio Tools
Sidebar **Audio**, or the **AUDIO TOOLS** card on Home. Both tools run on this PC; nothing is uploaded.
- **Beat Marker** does what editors do by hand with a drums-only track (render the audio, separate the drums, put markers on the drum hits), automatically:
  1. **Analyse and mark:** **Selected Layer** - select the song (or a clip with sound, or a precomp); the markers go on that layer. **Composition** - nothing to select; everything audible in the comp is analysed and the markers go on the composition's own timeline (composition markers). Only the **work area** is analysed (set it with B / N).
  2. **Markers on:** **Every beat**, **Every 2 beats**, **Every bar** (tempo **Auto**, **×2** or **½**) or **Drum hits** (every clear kick / snare hit, also off the beat - the hits you would see as spikes on the drums waveform).
  3. **ADD BEAT MARKERS:** the audio is read straight from the layer's file (or rendered: precomps, time-remapped clips, Composition), the drums are extracted with HT-Demucs FT drums (ONNX), the beat is tracked on the drums track (onset strength of a log mel spectrogram, tempo by autocorrelation, beats by dynamic programming, each snapped to the drum hit it falls on; no beats where the track is silent) and the markers are placed at those times. Running it again replaces Dala's earlier markers on that layer / comp instead of adding duplicates; **REMOVE MARKERS** deletes only those.
  - **Add the drums track** (on by default): the extracted drums are saved as "<name> [drums].wav" (next to the song in "Dala Stems", or `Documents\Dala Suite\Stems`) and added as a layer above the song (top of the comp for Composition), lined up, its audio off so the mix does not change - press LL on it to see the drum hits under the markers. Running it again replaces that layer.
  - A song with no drums: the beat is found on the full mix instead, and the panel says so.
  - Speed / memory: the drum extraction runs on the CPU at roughly 0.8-1x the length of the analysed audio plus ~20 s to start (a 3-minute song took about 3 minutes on the test laptop; peak memory about 1.5 GB).
  - Accuracy (test songs with known beats, drums plus off-beat bass, piano and vocals): every beat found (F-measure 1.00 at ±70 ms), median timing error under 2 ms, drum hits F-measure 0.93-0.97; finding the beat on the full mix instead scored 0.00-0.66 on the same songs.
  - Tested in After Effects 2025 (25.6) with a 112 BPM test song: Selected Layer on a song layer offset by 2 s (37 of 37 beats in the work area, median error 1.3 ms, one marker at the end of the work area 28 ms early), rerun (markers and drums track replaced, not doubled), Drum hits (42 of 42 hits, 2 extra), Composition on a precomp offset by 1.5 s (34 of 34 composition markers, max error 5.1 ms), Every bar, Remove markers, Selected Layer on a precomp layer (34 of 34). **Every bar** places bars on the strongest beat of 4; in songs with a kick on beats 1 and 3 it can start on beat 3 - shift by one beat if needed.
- **Vocal Remover:** separates the layer into **Vocals** and **Instrumental** WAV stems with Demucs v4 - **Fast** (`htdemucs`, 84 MB) or **Best** (`htdemucs_ft`, 4 × 84 MB; about 3-4× slower, best quality). The stems are saved next to the source file in "Dala Stems" (or `Documents\Dala Suite\Stems` when that folder is read-only) and, optionally, added to the comp above the original and lined up with it, with the original muted. **RECHECK MODELS** verifies the downloaded models.
- **Setup:** uses the Auto Captions speech engine (Beat Marker needs nothing else: the engine already includes ONNX Runtime; its drum model, 166 MB, downloads on the first run or with **DOWNLOAD**, and **RECHECK MODELS** verifies it); the Vocal Remover also needs a one-time add-on (PyTorch CPU + Demucs, pinned and hash-checked, about 1.4 GB on disk, a few minutes) into `%LOCALAPPDATA%\DalaSuite\audio`, and downloads its model once into `%USERPROFILE%\.cache\dala_whisper\models`, with the same resume / verify / repair as the speech models. Separation runs on the CPU: on this test laptop about 1.6× the audio length with Fast and 5.5× with Best.
- Tested in After Effects 2025 (25.6): beat markers on a song layer (rerun, ×2, remove) and a full vocal separation with the stems added to the comp.

### 12. Music Stems
Sidebar **Stems**, or the **MUSIC STEMS** card on Home. Runs on this PC; nothing is uploaded.
- **What you get:** five stems of the selected song - **Drums, Bass, Guitar, Piano, Other** - from HT-Demucs 6-stem (Meta, MIT; ONNX export by StemSplit, `StemSplitio/htdemucs-6s-onnx`). The model also predicts vocals; Dala never writes them.
- **How:** select the song layer (an audio file, a video with sound, a precomp, a stretched or time-remapped clip), choose **Whole layer** (all of it that is inside the comp) or **Work area**, press **EXTRACT STEMS**. A layer that plays one file straight is read from its file (only the part that is used); anything else is rendered as it sounds in the comp first.
- **In the comp:** five layers right above the song - "<song> [Drums]", [Bass], [Guitar], [Piano], [Other] (red, blue, orange, purple, green labels) - each starting where the split part starts, with the same in and out points, the song left as it was (or muted with **Mute the original layer**). Running it again on the same song replaces the earlier stems (and their project items).
- **Files:** 32-bit float WAV, 44.1 kHz stereo (no clipping; the five stems plus the vocals add back up to the song), in "Dala Stems" next to the song (or `Documents\Dala Suite\Stems`), named "<song> - Drums.wav"... A stem that is almost silent (a song without piano) is still delivered, and the panel says so.
- **Model:** 136 MB, pinned (size + SHA-256) in `whisper/models.json`, stored in `%USERPROFILE%\.cache\dala_whisper\models\htdemucs_6s`. Order of preference: the copy already installed (re-verified every run); a copy found on the PC (Hugging Face cache, Downloads, Desktop, Documents, `Documents\Dala Suite\Models` - same name and size, then the SHA-256 is checked, and it is copied, never moved); **USE FILE** for a copy anywhere else (`htdemucs_6s_fp16weights.onnx`, checked the same way - any other file is refused); otherwise a download from Hugging Face with exact progress, resume after an interruption, one download at a time, free-space check, and a re-download of a file that arrives damaged. **CHECK MODEL** verifies the checksum and test-loads the model.
- **Engine:** the Auto Captions speech engine (Python included; ONNX Runtime, PyAV, NumPy). Missing: **INSTALL ENGINE**; damaged: **REPAIR ENGINE**.
- **Speed / memory:** CPU, about 0.9× the length of the audio plus ~15 s to load the model (a 3-minute song: 2 min 45 s on the test laptop); memory stays at about 1.1 GB whatever the length (the audio is decoded and the stems are written a few seconds at a time). **Cancel** stops it and deletes the unfinished files.
- **Tested in After Effects 2025 (25.6), through the panel:** a song layer offset by 2 s (stems at 2.000 s, rendered stems vs the song: lag 0 samples at 48 kHz), the same song trimmed with Work area (lag 0), a precomp holding the song (rendered path, lag 0), rerun replacing stems, cancel, no selection / a solid / a stem layer selected (clear messages); on a fresh profile: engine install from the panel, the model downloaded on the first EXTRACT (progress in MB), split and added; download interrupted and resumed, a corrupted model re-downloaded before use, a copy in Downloads reused, a damaged copy refused.

### 13. SFX Extractor
Sidebar **SFX**, or the **SFX EXTRACTOR** card on Home. Pulls the **Centre channel** out of a movie's 5.1 sound: in a film mix it carries the original dialogue and the effects mixed with it (punches, kicks, sword clashes, impacts, whooshes, footsteps), while the music and ambience sit mostly on the other channels.
- **How:** select the movie clip in the comp (the file itself - MKV, MP4, MOV, an audio file - not a precomp), choose **Whole layer** or **Work area**, press **DETECT CHANNELS** to see the layout or **EXTRACT CENTRE** to do it.
- **Channel layout:** FFmpeg reads the file's audio tracks. A 5.1 track shows its six channels in order - for DD / DD+ / DTS usually **1 FL, 2 FR, 3 C, 4 LFE, 5 SL, 6 SR** - with the Centre highlighted. The Centre is taken **by name** (`pan=mono|c0=FC`: that one channel at gain 1, nothing else mixed in) - never all six downmixed, never a guess by position. 5.0, 6.1 and 7.1 work too. Mono, stereo, quad / 4.0 and audio with a channel count but no layout get a clear message instead. A file with several audio tracks shows a track picker (After Effects plays the first one); when that one is not 5.1 but another is, the panel says so.
- **Timing:** the part of the file the layer plays is cut with an exact seek (silence is added where the audio track starts late - the test movie's audio starts 3.749 s after its picture - or ends early) and the Centre layer gets the clip's start, stretch, time remapping (keys and eases copied, values shifted) and in / out points. The original layer is not changed. Running it again replaces the earlier Centre layer for that clip.
- **File:** mono 32-bit float WAV at the file's own sample rate (24-bit when a span is too long for one WAV), in "Dala SFX" next to the movie (or `Documents\Dala Suite\SFX`), named "<movie> - Centre <from> to <to>.wav".
- **FFmpeg:** the same pinned build GENERAL > Link uses, downloaded once (31 MB, SHA-256 checked) on the first run.
- **After Effects and 5.1** (measured in After Effects 2025 by rendering the clip and comparing with the file's six channels): 5.1 PCM (MOV) plays channels 1-2 only - no Centre, so no dialogue; AAC 5.1 (MP4) plays channels 2-3; Dolby Digital in MP4 plays about 6 ms early; Dolby Digital in MKV plays no sound at all (Dala still extracts it); DD+ (E-AC3, in MKV or MP4) plays from the wrong places (each block from about 2.4× further into the file). The picture itself is placed correctly (frames at 30 s and 20 min matched the file exactly). So judge the Centre layer against the picture, not against the clip's own sound.
- **Tested in After Effects 2025 (25.6), through the panel:** the 2 h 45 min DD+ 5.1(side) test movie - a 10 s clip at 20:00 placed at 2 s (Centre WAV bit-identical to FFmpeg's decoded Centre, layer at 2.000-12.000 s) and the whole movie (3 min 40 s, 1.9 GB, exactly 477,593,594 samples, silent until 3.749 s, bit-identical at 10:00); 40 s excerpts as PCM MOV, AAC MP4, DD+ MKV / MP4, AC-3 MKV / MP4: After Effects' render of every Centre layer equals the decoded Centre at lag 0 (gain 0.00 dB); time-remapped and 80 % stretched clips (lag 0 against the same remap / stretch applied to a full-length Centre); Work area; a two-track MKV (stereo first, 5.1 second); cancel; stereo clip, precomp, solid and nothing selected (messages); FFmpeg downloaded on a fresh profile.

---

## Configuration & Python Interface (`config/settings.py`)

Dala Suite provides a clean, fully-featured Python configuration interface and CLI to inspect and update extension settings:

```bash
# View all current settings as JSON
python config/settings.py --json

# Get currently configured preset root directory
python config/settings.py --get-preset-root

# Set custom preset root directory or folder name (e.g. Blizzards)
python config/settings.py --set-preset-root Blizzards

# Resolve the active presets directory path on disk
python config/settings.py --resolve-preset-dir
```

All settings are atomically synchronized with `config/settings.json` and persist across reloads.

---

## Dark Marine Blue Design System

Dala Suite features a modern Dark Marine Blue theme engineered specifically for video editors:
- **Base Surface:** Dark marine navy (`#070c14`, `#0c1422`, `#121e33`)
- **Accent Blue:** Electric marine blue (`#2979ff`, `#1565c0`)
- **Typography:** White headers (`#ffffff`), muted blue-gray subtitles (`#8ba3c7`)
- **Zero Yellow / Gold / Beige:** Warm yellow, orange, and gold accents are completely eliminated.
- **Fluid Responsiveness:** Works smoothly docked in narrow vertical panels (260px width) or wide multi-monitor layouts.
- **Normal Flow Header Banner:** The looping video header participates in normal layout flow without fixed-position overlay clipping or capturing pointer events. Can be toggled on/off in Settings.

---

## Windows Installation Guide

### Option A: Automatic ZXP Installation (Recommended)
1. Download **`DalaSuite-v2.0.6.zxp`**.
2. Open with **ZXP Installer**, **aescripts + aeplugins manager**, or **Anastasiy's Extension Manager**.
3. Launch Adobe After Effects (CC 2014 through 2026+).
4. Navigate to **Window &rarr; Extensions &rarr; Dala Suite**.

### Option B: Manual Folder Installation
1. Extract the contents of **`DalaSuite-v2.0.6.zxp`** (it is a zip archive).
2. Copy the `DalaSuite` folder into either of the following CEP extension paths on Windows:
   - **System-wide:**
     ```
     C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\DalaSuite\
     ```
   - **User-only:**
     ```
     C:\Users\<YourUsername>\AppData\Roaming\Adobe\CEP\extensions\DalaSuite\
     ```
3. Enable unsigned extensions in the Windows Registry (standard Adobe CEP requirement):
   - Press **Win + R**, type `regedit`, and hit Enter.
   - Navigate to `HKEY_CURRENT_USER\Software\Adobe\CSXS.10` (and `CSXS.11`, `CSXS.12`, `CSXS.14`, `CSXS.16`).
   - Create a new **String Value** named `PlayerDebugMode` with value `1`.
4. Open After Effects &rarr; **Window &rarr; Extensions &rarr; Dala Suite**.

---

## Automated Verification Suite

Run all verification test suites:
```bash
# Automated Functional Verification Suite (16 Tests)
node DalaSuite/tools/run-tests.js

# Full UI Interaction & Button Clickability Suite (16 Tests)
node DalaSuite/tools/test-interactions.js

# Time Validation & Dynamic Presets Suite (8 Tests)
node DalaSuite/tools/test-time-and-presets.js
```

All 40 tests pass with a 100% success rate.
