/**
 * Dala Suite - Main ExtendScript Host Entry Point
 * Adobe After Effects CEP Extension
 */

// Include all modules
#include "utilities.jsx"
#include "keyframeEngine.jsx"
#include "cutTools.jsx"
#include "twixtor.jsx"
#include "zoom.jsx"
#include "shake.jsx"
#include "presetEngine.jsx"
#include "framing.jsx"
#include "autoTracker.jsx"
#include "layerRecipe.jsx"
#include "captions.jsx"
#include "unprecompose.jsx"
#include "layerSetups.jsx"
#include "audioTools.jsx"
#include "musicStems.jsx"
#include "sfxExtractor.jsx"
#include "generalTools.jsx"
#include "editTools.jsx"
#include "anchorAlign.jsx"

// Check project status and active composition info
$._dalaSuite.getCompInfo = function () {
    try {
        if (!app.project) {
            return $._dalaSuite.formatResult(false, "No project open.", { hasComp: false });
        }
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            return $._dalaSuite.formatResult(true, "No active composition selected.", {
                hasComp: false,
                projectName: app.project.file ? app.project.file.name : "Untitled Project"
            });
        }

        var layers = comp.selectedLayers;
        var layerDetails = [];
        for (var i = 0; i < layers.length; i++) {
            var l = layers[i];
            layerDetails.push({
                index: l.index,
                name: l.name,
                inPoint: l.inPoint,
                outPoint: l.outPoint,
                durationFrames: Math.round((l.outPoint - l.inPoint) / comp.frameDuration),
                isText: (typeof TextLayer !== "undefined" && l instanceof TextLayer) || (l.property("Source Text") !== null)
            });
        }

        return $._dalaSuite.formatResult(true, "Comp info retrieved.", {
            hasComp: true,
            compName: comp.name,
            width: comp.width,
            height: comp.height,
            fps: Math.round(1 / comp.frameDuration * 1000) / 1000,
            frameDuration: comp.frameDuration,
            duration: comp.duration,
            selectedLayerCount: layers.length,
            selectedLayers: layerDetails
        });
    } catch (err) {
        return $._dalaSuite.formatResult(false, err.message || err.toString(), null, err.toString());
    }
};

// Open native folder selection dialog for custom preset root directory
$._dalaSuite.selectFolderDialog = function (promptTitle) {
    try {
        var defaultFolder = $._dalaSuite.presetEngine.getRootDir();
        var folder = Folder.selectDialog(promptTitle || "Select Preset Root Directory", defaultFolder);
        if (folder) {
            return $._dalaSuite.formatResult(true, "Folder selected.", {
                path: folder.fsName
            });
        } else {
            return $._dalaSuite.formatResult(false, "Folder selection cancelled.", null);
        }
    } catch (err) {
        return $._dalaSuite.formatResult(false, err.message || err.toString(), null, err.toString());
    }
};

// Ping / Version check
$._dalaSuite.ping = function () {
    return $._dalaSuite.formatResult(true, "Dala Suite Host API Active.", {
        version: "2.0.6",
        aeVersion: app.version,
        platform: $.os
    });
};
