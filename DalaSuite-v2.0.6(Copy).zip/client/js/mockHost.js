/**
 * Dala Suite - Host Simulator for Browser Preview & Testing
 * Emulates After Effects ExtendScript environment when running outside Adobe CEP.
 * Dark Marine Blue Pro Engine with 3-Layer Cut To F Split & Independent Multi-Layer Twixtor.
 */

(function () {
    'use strict';

    var simulator = {
        activeComp: {
            name: "blurs",
            width: 1440,
            height: 1600,
            fps: 60,
            frameDuration: 1 / 60,
            duration: 30.0,
            selectedLayers: [
                {
                    index: 1,
                    name: "clip1",
                    inPoint: 2.0, // frame 120
                    outPoint: 5.0, // frame 300 (duration = 180 frames)
                    isText: false
                },
                {
                    index: 2,
                    name: "clip2 - action cut",
                    inPoint: 5.0, // frame 300
                    outPoint: 7.5, // frame 450 (duration = 150 frames)
                    isText: false
                },
                {
                    index: 3,
                    name: "b-roll clip",
                    inPoint: 8.0,
                    outPoint: 11.0,
                    isText: false
                },
                {
                    index: 4,
                    name: "clip_slipped_negative",
                    inPoint: -0.1, // Slipped clip before 0s (reproduces production bug scenario)
                    outPoint: 4.0,
                    isText: false
                }
            ]
        },

        selectedLayerIndices: [1, 2], // Select clip1 and clip2 to test multi-layer!
        presetRootDir: "C:\\Users\\Editor\\Documents\\DalaSuite",
        debugLogs: [],
        presets: [
            { name: "Individual Clip Shake 1", filename: "Individual Clip Shake 1.ffx", category: "shake", path: "presets/shake/Individual Clip Shake 1.ffx", size: 47472 },
            { name: "Individual Clip Shake 2", filename: "Individual Clip Shake 2.ffx", category: "shake", path: "presets/shake/Individual Clip Shake 2.ffx", size: 63758 },
            { name: "Individual Clip Shake 3", filename: "Individual Clip Shake 3.ffx", category: "shake", path: "presets/shake/Individual Clip Shake 3.ffx", size: 64302 },
            { name: "Individual Clip Shake 4", filename: "Individual Clip Shake 4.ffx", category: "shake", path: "presets/shake/Individual Clip Shake 4.ffx", size: 41524 },
            { name: "Individual Clip Shake 5", filename: "Individual Clip Shake 5.ffx", category: "shake", path: "presets/shake/Individual Clip Shake 5.ffx", size: 101244 },
            { name: "Premium Individual Clip Shake + Zoom in", filename: "Premium Individual Clip Shake + Zoom in.ffx", category: "shake", path: "presets/shake/Premium Individual Clip Shake + Zoom in.ffx", size: 122584 },
            { name: "c-c shake1", filename: "c-c shake1.ffx", category: "shake", path: "presets/shake/c-c shake1.ffx", size: 49422 },
            { name: "hard shake+ lens blur", filename: "hard shake+ lens blur.ffx", category: "shake", path: "presets/shake/hard shake+ lens blur.ffx", size: 110372 },
            { name: "seamless shake", filename: "seamless shake.ffx", category: "shake", path: "presets/shake/seamless shake.ffx", size: 136140 },
            { name: "shake+lens blur", filename: "shake+lens blur.ffx", category: "shake", path: "presets/shake/shake+lens blur.ffx", size: 131336 },
            { name: "reverse-twix", filename: "reverse-twix.ffx", category: "twixtor", path: "presets/twixtor/reverse-twix.ffx", size: 18934 },
            { name: "twixtor 240 speedramp", filename: "twixtor 240 speedramp.ffx", category: "twixtor", path: "presets/twixtor/twixtor 240 speedramp.ffx", size: 24612 },
            { name: "twixtor dialogue", filename: "twixtor dialogue.ffx", category: "twixtor", path: "presets/twixtor/twixtor dialogue.ffx", size: 24436 },
            { name: "twixtor mid fast speedramp", filename: "twixtor mid fast speedramp.ffx", category: "twixtor", path: "presets/twixtor/twixtor mid fast speedramp.ffx", size: 24612 },
            { name: "aggressive ZOOM IN", filename: "aggressive ZOOM IN.ffx", category: "zoom", path: "presets/zoom/aggressive ZOOM IN.ffx", size: 29907 },
            { name: "microwave zoom", filename: "microwave zoom.ffx", category: "zoom", path: "presets/zoom/microwave zoom.ffx", size: 31082 },
            { name: "myzoom", filename: "myzoom.ffx", category: "zoom", path: "presets/zoom/myzoom.ffx", size: 30004 }
        ],

        getCategories: function () {
            var cats = [];
            for (var i = 0; i < this.presets.length; i++) {
                var c = this.presets[i].category;
                if (cats.indexOf(c) === -1) cats.push(c);
            }
            return cats;
        },

        renameFolder: function (oldName, newName) {
            for (var i = 0; i < this.presets.length; i++) {
                if (this.presets[i].category.toLowerCase() === oldName.toLowerCase()) {
                    this.presets[i].category = newName;
                    this.presets[i].path = "presets/" + newName + "/" + this.presets[i].filename;
                }
            }
        },

        addFolder: function (folderName, presetNames) {
            var names = presetNames || ["preset1.ffx", "preset2.ffx"];
            for (var i = 0; i < names.length; i++) {
                var fn = names[i];
                this.presets.push({
                    name: fn.replace(/\.ffx$/i, ""),
                    filename: fn,
                    category: folderName,
                    path: "presets/" + folderName + "/" + fn,
                    size: 15000
                });
            }
        },

        removeFolder: function (folderName) {
            this.presets = this.presets.filter(function (p) {
                return p.category.toLowerCase() !== folderName.toLowerCase();
            });
        },

        log: function (msg) {
            this.debugLogs.push(String(msg));
            console.log("[AE Host Sim] " + msg);
        },

        setSafeCompTime: function (time) {
            var minTime = 0;
            var maxTime = this.activeComp.duration || 10800;
            var safeTime = Math.max(minTime, Math.min(maxTime, typeof time === 'number' ? time : 0));
            this.activeComp.time = safeTime;
            return safeTime;
        },

        evalScript: function (script, callback) {
            var self = this;
            this.debugLogs = [];

            setTimeout(function () {
                var response = self.handleScript(script);
                if (typeof callback === 'function') {
                    callback(JSON.stringify(response));
                }
            }, 50);
        },

        handleScript: function (script) {
            // Auto Captions > CAPTION STYLE: what the style needs that "this PC" lacks
            if (script.indexOf("captions.styleCheck") !== -1) {
                return { success: true, message: "ok", data: { missingEffects: ["S_WipeLine", "BCC Halftone"], missingFonts: ["GameOfSquids"], fontsChecked: true } };
            }
            // GENERAL > Edit tools (host/editTools.jsx, unprecompose.jsx, generalTools.jsx)
            if (script.indexOf("$._dalaSuite.edit.") !== -1 || script.indexOf("unprecompose.run") !== -1 || script.indexOf("$._dalaSuite.general.") !== -1) {
                var n = this.getSelectedLayers().length;
                if (script.indexOf("edit.create") !== -1) {
                    var type = (/\\"type\\":\\"(\w+)\\"/.exec(script) || [0, "solid"])[1];
                    return { success: true, message: "“" + ({ text: "Your text", adjustment: "Adjustment Layer", solid: "Solid", "null": "clip1 · control" }[type] || type) + "” added" };
                }
                if (script.indexOf("edit.precompose") !== -1) return script.indexOf('\\"each\\":true') !== -1 ? { success: true, message: n + " precomps created, one per layer" } : { success: true, message: "Precomposed as “clip1 +" + (n - 1) + "”" };
                if (script.indexOf("unprecompose.run") !== -1) return { success: true, message: "5 layers back in the comp" };
                if (script.indexOf("edit.copyFx") !== -1) return { success: true, message: "Copied 2 effects of “clip1” · 6 keyframes" };
                if (script.indexOf("edit.pasteFx") !== -1) return { success: true, message: "Pasted on " + n + " layers · animation fitted to " + n + " clips" };
                if (script.indexOf("edit.duplicate") !== -1) return { success: false, message: "Select a precomp layer: Duplicate makes an independent copy of a precomp." };
                if (script.indexOf("edit.curveApply") !== -1) return { success: true, message: "ok", data: { count: 3 } };
                if (script.indexOf("edit.curveRead") !== -1) return { success: true, message: "ok", data: { total: 2, pairs: [
                    { prop: "Position", layer: "clip1", k1: 1, k2: 2, t1: 0, t2: 0.8, frames: 48, v1: "960, 540", v2: "1400, 540", outInf: 82, inInf: 64, outSpeed: 0, inSpeed: 0, avg: 550, linear: false, hold: false, curve: { outInf: 82, inInf: 64, outRatio: 0, inRatio: 0 } },
                    { prop: "Scale", layer: "clip1", k1: 2, k2: 3, t1: 0.8, t2: 1.5, frames: 42, v1: "100, 100", v2: "120, 120", outInf: 33, inInf: 33, outSpeed: 0, inSpeed: 0, avg: 28.6, linear: false, hold: false, curve: { outInf: 33, inInf: 33, outRatio: 0, inRatio: 0 } }] } };
                if (script.indexOf("edit.importMedia") !== -1) return { success: true, message: "Imported in the comp" };
                if (script.indexOf("general.beatCheck") !== -1) return { success: true, message: "Added 33 coloured solids, one per beat interval" };
                return { success: true, message: "Placed 4 clips on the beats" };
            }

            // 1. Get Comp Info
            if (script.indexOf("getCompInfo") !== -1) {
                var layers = this.getSelectedLayers();
                return {
                    success: true,
                    message: "Comp info retrieved.",
                    data: {
                        hasComp: true,
                        compName: this.activeComp.name,
                        width: this.activeComp.width,
                        height: this.activeComp.height,
                        fps: this.activeComp.fps,
                        frameDuration: this.activeComp.frameDuration,
                        duration: this.activeComp.duration,
                        selectedLayerCount: layers.length,
                        selectedLayers: layers
                    },
                    debugLogs: ["[Simulator] Active comp: " + this.activeComp.name + " (" + this.activeComp.width + "x" + this.activeComp.height + " @ " + this.activeComp.fps + " FPS)"]
                };
            }

            // 2. Cut To F: Splits layer into 3 parts (First 2F + Mid + Last 2F), disables Frame Blending on head/tail, and pre-composes
            if (script.indexOf("cutToF") !== -1) {
                var selected = this.getSelectedLayers();
                if (selected.length === 0) {
                    return { success: false, message: "Select one or more layers.", error: "No layers selected." };
                }

                var fd = this.activeComp.frameDuration;
                var processed = [];
                var skipped = [];

                this.log("Cut To F: Splitting " + selected.length + " layer(s) into 3 segments (First 2F + Mid + Last 2F) & pre-composing...");

                for (var i = 0; i < selected.length; i++) {
                    var l = selected[i];
                    var dur = l.outPoint - l.inPoint;
                    var totalFrames = Math.round(dur / fd);
                    if (totalFrames < 5) {
                        var errMsg = "Layer \"" + l.name + "\" is too short for Cut to F (Duration: " + totalFrames + "f, minimum 5f required for 2F Head + Mid + 2F Tail).";
                        this.log("Validation notice: " + errMsg);
                        skipped.push({ layerName: l.name, reason: errMsg });
                        continue;
                    }

                    var t0 = l.inPoint;
                    var t1 = l.inPoint + (2 * fd);
                    var t2 = l.outPoint - (2 * fd);
                    var t3 = l.outPoint;

                    var f0 = Math.round(t0 / fd);
                    var f1 = Math.round(t1 / fd);
                    var f2 = Math.round(t2 / fd);
                    var f3 = Math.round(t3 / fd);

                    var precompName = l.name + " [Cut to F]";
                    var spanDuration = t3 - t0;

                    this.log("Layer [" + l.index + "] \"" + l.name + "\" split:");
                    this.log("  - Head (First 2F): " + f0 + "f -> " + f1 + "f (2 frames) [Frame Blending: OFF]");
                    this.log("  - Mid: " + f1 + "f -> " + f2 + "f (" + (f2 - f1) + " frames) [Frame Blending: Unchanged]");
                    this.log("  - Tail (Last 2F): " + f2 + "f -> " + f3 + "f (2 frames) [Frame Blending: OFF]");
                    this.log("  - Pre-composed into \"" + precompName + "\" (Move All Attributes: true, Adjust Comp Duration: true, Open: false)");

                    processed.push({
                        originalName: l.name,
                        precompName: precompName,
                        timeSpan: { inPoint: t0, outPoint: t3, duration: spanDuration, frames: totalFrames },
                        headFrames: 2,
                        midFrames: f2 - f1,
                        tailFrames: 2,
                        frameBlendingDisabledOnEdges: true,
                        precomposeSettings: {
                            moveAllAttributes: true,
                            adjustCompDuration: true,
                            openNewComp: false
                        }
                    });
                }

                if (processed.length === 0 && skipped.length > 0) {
                    return { success: false, message: skipped[0].reason, error: skipped[0].reason, debugLogs: this.debugLogs };
                }

                return {
                    success: true,
                    message: "Cut to F: Processed " + processed.length + " layer" + (processed.length === 1 ? "" : "s") + " (First 2F + Mid + Last 2F) & pre-composed independently.",
                    data: { processed: processed, skipped: skipped, count: processed.length },
                    debugLogs: this.debugLogs
                };
            }

            // 3. Twixtor Dialog: Unchecks "In FPS is Out FPS" and sets Input: Frame Rate
            if (script.indexOf("applyDialog") !== -1 || script.indexOf("applyTwixtorDialog") !== -1) {
                var fpsMatch = script.match(/apply(?:Twixtor)?Dialog\(([^,)]+)/);
                var fpsVal = fpsMatch ? fpsMatch[1].replace(/['"]/g, '').trim() : "60";
                var selected = this.getSelectedLayers();
                if (selected.length === 0) {
                    return { success: false, message: "Select one or more layers.", error: "No layers selected." };
                }

                this.log("Applying Twixtor Dialog preset to " + selected.length + " layer(s) independently (FPS=" + fpsVal + ")");
                var layersResult = [];
                for (var i = 0; i < selected.length; i++) {
                    var l = selected[i];
                    this.log("----------------------------------------");
                    this.log("Layer: " + l.name + " (Layer In: " + l.inPoint.toFixed(2) + "s, Out: " + l.outPoint.toFixed(2) + "s)");
                    this.log("  Preset: twixtor dialogue.ffx");
                    this.log("  Twixtor Effect: exactly 1 effect applied");
                    this.log("  In FPS is Out FPS checkbox: unchecked (value = 0)");
                    this.log("  Input: Frame Rate: " + fpsVal);
                    layersResult.push({ layerName: l.name, index: l.index, fps: fpsVal });
                }

                return {
                    success: true,
                    message: "Applied Twixtor Dialog (" + fpsVal + " FPS, In FPS is Out FPS unchecked) to " + layersResult.length + " layer(s).",
                    data: { count: layersResult.length, layers: layersResult },
                    debugLogs: this.debugLogs
                };
            }

            // 4. Twixtor Speed: Independent multi-layer processing without playhead interference
            if (script.indexOf("applySpeed") !== -1 || script.indexOf("applyTwixtorSpeed") !== -1) {
                var fpsMatch = script.match(/apply(?:Twixtor)?Speed\(([^,)]+)/);
                var fpsVal = fpsMatch ? fpsMatch[1].replace(/['"]/g, '').trim() : "60";
                var shouldStretch = script.indexOf("false") === -1;
                var selected = this.getSelectedLayers();
                if (selected.length === 0) {
                    return { success: false, message: "Select one or more layers.", error: "No layers selected." };
                }

                this.log("Applying Twixtor Speed independently to " + selected.length + " layer(s) (Stretch: " + (shouldStretch ? "ON" : "OFF") + ") at FPS=" + fpsVal);
                var layersResult = [];

                for (var i = 0; i < selected.length; i++) {
                    var l = selected[i];
                    var durFrames = Math.round((l.outPoint - l.inPoint) / this.activeComp.frameDuration);
                    var origFrames = 48;
                    var ratio = durFrames / origFrames;

                    this.log("----------------------------------------");
                    this.log("LAYER [" + (i + 1) + "/" + selected.length + "]: " + l.name);
                    this.log("  InPoint: " + l.inPoint.toFixed(2) + "s, OutPoint: " + l.outPoint.toFixed(2) + "s (Duration: " + durFrames + " frames)");
                    this.log("  Deselected all other layers -> selected only " + l.name);
                    this.log("  Comp time set to layer inPoint (" + l.inPoint.toFixed(2) + "s) -> Playhead position has ZERO effect");
                    this.log("  Twixtor Effect: Found exactly 1 effect");
                    this.log("  In FPS is Out FPS checkbox: unchecked (value = 0)");
                    this.log("  Input: Frame Rate set to " + fpsVal);

                    if (shouldStretch) {
                        var midTime = l.inPoint + (l.outPoint - l.inPoint) * 0.5;
                        this.log("  First Keyframe: exactly at layer inPoint (" + l.inPoint.toFixed(2) + "s)");
                        this.log("  Middle Keyframe: at 50% layer duration (" + midTime.toFixed(2) + "s)");
                        this.log("  Last Keyframe: exactly at layer outPoint (" + l.outPoint.toFixed(2) + "s)");
                        this.log("  Stretch ratio: " + ratio.toFixed(4) + " (velocity curves preserved)");
                    } else {
                        this.log("  Authored keyframe timing preserved (stretch disabled).");
                    }

                    layersResult.push({
                        layerName: l.name,
                        index: l.index,
                        durationFrames: durFrames,
                        fps: fpsVal,
                        stretched: shouldStretch
                    });
                }
                this.log("Restored original playhead position and multi-selection.");

                return {
                    success: true,
                    message: "Applied Twixtor Speed (" + fpsVal + " FPS) independently to " + layersResult.length + " layer(s)" + (shouldStretch ? " (stretched)." : "."),
                    data: { count: layersResult.length, layers: layersResult },
                    debugLogs: this.debugLogs
                };
            }

            // 5. Apply Zoom: Independent per-layer processing & dynamic center
            if (script.indexOf("applyZoom") !== -1) {
                var selected = this.getSelectedLayers();
                if (selected.length === 0) {
                    return { success: false, message: "Select one or more layers.", error: "No layers selected." };
                }

                var shouldStretch = script.indexOf("false") === -1;
                var cx = this.activeComp.width / 2.0;
                var cy = this.activeComp.height / 2.0;

                this.log("Comp dimensions: " + this.activeComp.width + "x" + this.activeComp.height);
                this.log("Dynamic Zoom Center: [" + cx + ", " + cy + "]");

                var layersResult = [];
                for (var i = 0; i < selected.length; i++) {
                    var l = selected[i];
                    var durFrames = Math.round((l.outPoint - l.inPoint) / this.activeComp.frameDuration);

                    this.log("Processing Layer [" + l.index + "] \"" + l.name + "\" independently:");
                    this.log("  Zoom Center adapted to comp: [" + cx + ", " + cy + "]");
                    if (shouldStretch) {
                        this.log("  Keyframes stretched to layer: " + l.inPoint.toFixed(2) + "s -> " + l.outPoint.toFixed(2) + "s (" + durFrames + " frames)");
                    }

                    layersResult.push({
                        layerName: l.name,
                        index: l.index,
                        compCenter: [cx, cy],
                        stretched: shouldStretch
                    });
                }

                return {
                    success: true,
                    message: "Applied Zoom (" + this.activeComp.width + "x" + this.activeComp.height + ", Center [" + cx + ", " + cy + "]) to " + layersResult.length + " layer(s).",
                    data: { compCenter: [cx, cy], count: layersResult.length, layers: layersResult },
                    debugLogs: this.debugLogs
                };
            }

            // 6. Apply Shake: Independent per-layer processing
            if (script.indexOf("applyShake") !== -1) {
                var selected = this.getSelectedLayers();
                if (selected.length === 0) {
                    return { success: false, message: "Select one or more layers.", error: "No layers selected." };
                }

                var shouldStretch = script.indexOf("true") !== -1;
                var presetMatch = script.match(/applyShake\(['"]([^'"]+)['"]/);
                var presetName = presetMatch ? presetMatch[1] : "soft advanced twitch";

                this.log("Applying Shake preset: " + presetName + " to " + selected.length + " layer(s) independently (Stretch: " + (shouldStretch ? "ON" : "OFF") + ")");

                var layersResult = [];
                for (var i = 0; i < selected.length; i++) {
                    var l = selected[i];
                    this.log("Layer: " + l.name + " -> Shake preset applied independently");
                    layersResult.push({ layerName: l.name, index: l.index, stretched: shouldStretch });
                }

                return {
                    success: true,
                    message: "Applied " + presetName.replace(/\.ffx$/i, "") + " to " + layersResult.length + " layer(s)" + (shouldStretch ? " (stretched)." : " (authored timing)."),
                    data: { count: layersResult.length, layers: layersResult, stretched: shouldStretch },
                    debugLogs: this.debugLogs
                };
            }

            // 7. Apply Generic Preset (with independent per-layer keyframe stretch)
            if (script.indexOf("applyGenericPreset") !== -1) {
                var selected = this.getSelectedLayers();
                if (selected.length === 0) {
                    return { success: false, message: "Select one or more layers.", error: "No layers selected." };
                }

                var shouldStretch = script.indexOf("false") === -1;
                var pathMatch = script.match(/applyGenericPreset\(([^,)]+)/);
                var rawPath = pathMatch ? pathMatch[1].replace(/['"]/g, '').trim() : "preset.ffx";
                var pName = rawPath.split(/[\\/]/).pop().replace(/\.ffx$/i, "");

                this.log("Applying Preset: " + pName + " to " + selected.length + " layer(s) independently (Stretch: " + (shouldStretch ? "ON" : "OFF") + ")");

                var layersResult = [];
                for (var i = 0; i < selected.length; i++) {
                    var l = selected[i];
                    var dur = (l.outPoint - l.inPoint).toFixed(2);
                    this.log("  Layer [" + l.index + "] \"" + l.name + "\": inPoint=" + l.inPoint.toFixed(2) + "s, outPoint=" + l.outPoint.toFixed(2) + "s (dur: " + dur + "s)");
                    if (shouldStretch) {
                        this.log("    Keyframe times remapped from " + l.inPoint.toFixed(2) + "s to " + l.outPoint.toFixed(2) + "s (values & curves untouched)");
                    }
                    layersResult.push({ layerName: l.name, index: l.index, stretched: shouldStretch });
                }

                return {
                    success: true,
                    message: "Applied preset \"" + pName + "\" to " + layersResult.length + " layer(s)" + (shouldStretch ? " (stretched)." : "."),
                    data: { count: layersResult.length, layers: layersResult, stretched: shouldStretch },
                    debugLogs: this.debugLogs
                };
            }

            // 8. Scan Presets (Dynamic Category Discovery & Folder Support)
            if (script.indexOf("scanPresets") !== -1) {
                var presets = this.presets;
                var categories = this.getCategories();

                return {
                    success: true,
                    message: "Discovered " + presets.length + " presets.",
                    data: {
                        rootDir: this.presetRootDir,
                        rootFolderName: "presets",
                        categories: categories,
                        presets: presets
                    },
                    debugLogs: ["[Simulator] Discovered " + presets.length + " .ffx presets in " + this.presetRootDir + " (categories: " + categories.join(", ") + ")"]
                };
            }

            // 8b. Set Custom Root Dir
            if (script.indexOf("setCustomRootDir") !== -1) {
                var rootMatch = script.match(/setCustomRootDir\(([^)]*)\)/);
                if (rootMatch) {
                    var parts = rootMatch[1].split(',');
                    var p1 = parts[0] ? parts[0].replace(/['"]/g, '').trim() : '';
                    if (p1) this.presetRootDir = p1;
                }
                return {
                    success: true,
                    message: "Preset root directory updated.",
                    data: { path: this.presetRootDir }
                };
            }

            // 9. Folder Dialog
            if (script.indexOf("selectFolderDialog") !== -1) {
                var newDir = prompt("Enter custom Preset Root Directory path (e.g. D:\\DalaSuitePresets):", this.presetRootDir);
                if (newDir) {
                    this.presetRootDir = newDir;
                    return { success: true, message: "Folder selected.", data: { path: newDir }, debugLogs: ["[Simulator] Folder selected: " + newDir] };
                } else {
                    return { success: false, message: "Folder selection cancelled." };
                }
            }

            return {
                success: true,
                message: "Executed.",
                data: null,
                debugLogs: ["[Simulator] Eval: " + script]
            };
        },

        getSelectedLayers: function () {
            var self = this;
            return this.activeComp.selectedLayers.filter(function (l) {
                return self.selectedLayerIndices.indexOf(l.index) !== -1;
            });
        },

        toggleLayerSelection: function (layerIndex) {
            var idx = this.selectedLayerIndices.indexOf(layerIndex);
            if (idx === -1) {
                this.selectedLayerIndices.push(layerIndex);
            } else {
                this.selectedLayerIndices.splice(idx, 1);
            }
        },

        setCompResolution: function (w, h) {
            this.activeComp.width = w;
            this.activeComp.height = h;
        }
    };

    window.DalaHostSimulator = simulator;
})();
