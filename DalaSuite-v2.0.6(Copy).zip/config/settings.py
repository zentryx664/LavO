#!/usr/bin/env python3
"""
Dala Suite - Configuration Settings Module
Provides an interface to read, configure, and synchronize extension settings,
including dynamic preset root directory and folder name (e.g. Blizzards).
"""

import os
import sys
import json
import argparse
from typing import Any, Dict, Optional

CONFIG_DIR = os.path.dirname(os.path.abspath(__file__))
SETTINGS_FILE = os.path.join(CONFIG_DIR, "settings.json")
EXTENSION_ROOT = os.path.dirname(CONFIG_DIR)

DEFAULT_SETTINGS: Dict[str, Any] = {
    "version": "2.0.6",
    "presetRootDir": "",
    "presetFolderName": "presets",
    "showBannerVideo": True,
    "debugMode": False,
    "defaultFps": 24,
    "cutFrames": 2,
    "shakeStretchKeyframes": False,
    "zoomStretchKeyframes": True,
}


def get_settings_file_path() -> str:
    """Return the absolute path to settings.json."""
    return SETTINGS_FILE


def get_extension_root_path() -> str:
    """Return the absolute path to the DalaSuite extension root directory."""
    return EXTENSION_ROOT


def get_settings() -> Dict[str, Any]:
    """Read and return current settings from settings.json, merging with defaults."""
    if not os.path.exists(SETTINGS_FILE):
        save_settings(DEFAULT_SETTINGS.copy())
        return DEFAULT_SETTINGS.copy()

    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Merge missing defaults
        merged = DEFAULT_SETTINGS.copy()
        merged.update(data)
        return merged
    except Exception as err:
        sys.stderr.write(f"Warning: Failed to parse settings.json ({err}), returning defaults.\n")
        return DEFAULT_SETTINGS.copy()


def save_settings(settings: Dict[str, Any]) -> None:
    """Atomically write settings dictionary to settings.json."""
    temp_file = SETTINGS_FILE + ".tmp"
    with open(temp_file, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(temp_file, SETTINGS_FILE)


def get_setting(key: str, default: Any = None) -> Any:
    """Get a specific setting value."""
    settings = get_settings()
    return settings.get(key, default)


def set_setting(key: str, value: Any) -> Dict[str, Any]:
    """Update a specific setting and persist it."""
    settings = get_settings()
    settings[key] = value
    save_settings(settings)
    return settings


def get_preset_root() -> str:
    """Get configured preset root directory path."""
    return str(get_setting("presetRootDir", ""))


def set_preset_root(path_or_name: str) -> Dict[str, Any]:
    """
    Set configured preset root directory or folder name.
    If given a simple folder name (e.g. 'Blizzards'), it can also update presetFolderName.
    """
    settings = get_settings()
    cleaned = path_or_name.strip() if path_or_name else ""
    settings["presetRootDir"] = cleaned

    # If it's a simple folder name (no path separators), also set presetFolderName
    if cleaned and not os.path.isabs(cleaned) and "/" not in cleaned and "\\" not in cleaned:
        settings["presetFolderName"] = cleaned

    save_settings(settings)
    return settings


def get_preset_folder_name() -> str:
    """Get the preset folder name (e.g. 'presets' or 'Blizzards')."""
    return str(get_setting("presetFolderName", "presets"))


def set_preset_folder_name(name: str) -> Dict[str, Any]:
    """Set the preset folder name."""
    cleaned = name.strip() if name else "presets"
    return set_setting("presetFolderName", cleaned)


def resolve_preset_directory(custom_path_or_name: Optional[str] = None) -> str:
    """
    Resolves the actual existing directory path for presets based on configuration or input.
    Checks:
      1. Explicit path_or_name (absolute or relative to extension root)
      2. settings.presetRootDir
      3. settings.presetFolderName relative to extension root (e.g. <ext>/Blizzards)
      4. settings.presetFolderName inside <ext>/presets (e.g. <ext>/presets/Blizzards)
      5. Fallback: <ext>/presets
    """
    target = custom_path_or_name if custom_path_or_name is not None else get_preset_root()
    folder_name = get_preset_folder_name()

    if target:
        if os.path.isabs(target) and os.path.isdir(target):
            return target
        rel_path = os.path.join(EXTENSION_ROOT, target)
        if os.path.isdir(rel_path):
            return rel_path
        rel_presets = os.path.join(EXTENSION_ROOT, "presets", target)
        if os.path.isdir(rel_presets):
            return rel_presets

    # Check folder_name
    if folder_name:
        named_root = os.path.join(EXTENSION_ROOT, folder_name)
        if os.path.isdir(named_root):
            return named_root
        named_sub = os.path.join(EXTENSION_ROOT, "presets", folder_name)
        if os.path.isdir(named_sub):
            return named_sub

    # Default fallback
    default_dir = os.path.join(EXTENSION_ROOT, "presets")
    return default_dir


def main():
    parser = argparse.ArgumentParser(description="Dala Suite Settings Manager")
    parser.add_argument("--get-preset-root", action="store_true", help="Print configured preset root directory")
    parser.add_argument("--set-preset-root", type=str, metavar="PATH_OR_NAME", help="Set preset root directory or folder name")
    parser.add_argument("--get-preset-folder", action="store_true", help="Print configured preset folder name")
    parser.add_argument("--set-preset-folder", type=str, metavar="NAME", help="Set preset folder name (e.g. Blizzards)")
    parser.add_argument("--resolve-preset-dir", action="store_true", help="Print resolved existing presets directory")
    parser.add_argument("--get", type=str, metavar="KEY", help="Get value for setting key")
    parser.add_argument("--set", nargs=2, metavar=("KEY", "VALUE"), help="Set setting key and value")
    parser.add_argument("--list", action="store_true", help="List all current settings")
    parser.add_argument("--json", action="store_true", help="Output all settings as JSON")

    args = parser.parse_args()

    if args.get_preset_root:
        print(get_preset_root())
        return

    if args.set_preset_root is not None:
        set_preset_root(args.set_preset_root)
        print(f"presetRootDir set to: {get_preset_root()}")
        return

    if args.get_preset_folder:
        print(get_preset_folder_name())
        return

    if args.set_preset_folder is not None:
        set_preset_folder_name(args.set_preset_folder)
        print(f"presetFolderName set to: {get_preset_folder_name()}")
        return

    if args.resolve_preset_dir:
        print(resolve_preset_directory())
        return

    if args.get:
        val = get_setting(args.get)
        print(val if val is not None else "")
        return

    if args.set:
        key, raw_val = args.set
        # Type coerce booleans and numbers if appropriate
        if raw_val.lower() == "true":
            val = True
        elif raw_val.lower() == "false":
            val = False
        else:
            try:
                val = int(raw_val)
            except ValueError:
                try:
                    val = float(raw_val)
                except ValueError:
                    val = raw_val
        set_setting(key, val)
        print(f"{key} set to: {val}")
        return

    if args.json or args.list:
        print(json.dumps(get_settings(), indent=2))
        return

    # Default: print summary
    settings = get_settings()
    print("Dala Suite Settings:")
    for k, v in settings.items():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
